import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import os

# Set timeout and concurrent requests
timeout = 3
max_workers = 50  # Average concurrent requests for Google Colab

# Set input and output files
input_file = 'proxy.txt'
output_file = 'alive.txt'
dead_file = 'dead.txt'
remaining_file = 'remaining.txt'

# Initialize alive and dead proxies sets
alive_proxies = set()
dead_proxies = set()
remaining_proxies = set()

def check_proxy(proxy):
    try:
        proxy_dict = {
            'http': f'http://{proxy}',
            'https': f'http://{proxy}'
        }
        response = requests.get('http://example.com', proxies=proxy_dict, timeout=timeout)
        if response.status_code == 200:
            return True
        else:
            return False
    except requests.exceptions.RequestException:
        return False

def process_proxies(proxies):
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(check_proxy, proxy): proxy for proxy in proxies}
        for future in as_completed(futures):
            proxy = futures[future]
            try:
                if future.result():
                    alive_proxies.add(proxy)
                    with open(output_file, 'a') as f:
                        f.write(proxy + '\n')
                else:
                    dead_proxies.add(proxy)
                    with open(dead_file, 'a') as f:
                        f.write(proxy + '\n')
            except Exception as e:
                print(f"Error processing proxy {proxy}: {e}")

def read_proxies(file_path):
    try:
        with open(file_path, 'r') as f:
            proxies = f.read().splitlines()
            return proxies
    except FileNotFoundError:
        print("Proxy file not found.")
        return []

def save_proxies():
    with open(remaining_file, 'w') as f:
        f.write('\n'.join(remaining_proxies))

def upload_to_pastebin(alive_proxies):
    api_dev_key = '7hsy_5C5vDudnI59GRl5y5y9r48OAIh2'  # Get your API key from Pastebin
    api_paste_code = '\n'.join(alive_proxies)
    api_paste_name = 'Alive Proxies'
    api_paste_private = '1'  # 0=public, 1=unlisted, 2=private
    api_paste_expire_date = '1D'  # 1 day

    data = {
        'api_dev_key': api_dev_key,
        'api_option': 'paste',
        'api_paste_code': api_paste_code,
        'api_paste_name': api_paste_name,
        'api_paste_private': api_paste_private,
        'api_paste_expire_date': api_paste_expire_date
    }

    response = requests.post('https://pastebin.com/api/api_post.php', data=data)
    if response.status_code == 200:
        return response.text
    else:
        return None

def main():
    global alive_proxies, dead_proxies, remaining_proxies
    try:
        proxies = read_proxies(input_file)
        chunk_size = 100
        remaining_proxies = set(proxies)
        while remaining_proxies:
            chunk = list(remaining_proxies)[:chunk_size]
            process_proxies(chunk)
            remaining_proxies -= set(chunk)
            save_proxies()
            print(f"Remaining proxies: {len(remaining_proxies)}")

        # Upload alive proxies to Pastebin
        with open(output_file, 'r') as f:
            alive_proxies = f.read().splitlines()
        pastebin_link = upload_to_pastebin(alive_proxies)
        if pastebin_link:
            print(f"Alive proxies uploaded to Pastebin: {pastebin_link}")
        else:
            print("Failed to upload alive proxies to Pastebin")

    except KeyboardInterrupt:
        print("Interrupted. Saving progress...")
        save_proxies()
    except Exception as e:
        print(f"Error: {e}")
    finally:
        save_proxies()

if __name__ == '__main__':
    main()