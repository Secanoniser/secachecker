import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# Set timeout and concurrent requests
timeout = 3
max_workers = 50  # Average concurrent requests for Google Colab

# Set input and output files
input_file = 'proxy.txt'
output_file = 'alive.txt'
dead_file = 'dead.txt'

# Initialize alive and dead proxies sets
alive_proxies = set()
dead_proxies = set()

def check_proxy(proxy):
    try:
        proxy_dict = {
            'http': f'http://{proxy}',
            'https': f'http://{proxy}'
        }
        response = requests.get('http://example.com', proxies=proxy_dict, timeout=timeout)
        if response.status_code == 200:
            return True
        else:
            return False
    except requests.exceptions.RequestException:
        return False

def process_proxies(proxies):
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(check_proxy, proxy): proxy for proxy in proxies}
        for future in as_completed(futures):
            proxy = futures[future]
            try:
                if future.result():
                    alive_proxies.add(proxy)
                    with open(output_file, 'a') as f:
                        f.write(proxy + '\n')
                else:
                    dead_proxies.add(proxy)
                    with open(dead_file, 'a') as f:
                        f.write(proxy + '\n')
            except Exception as e:
                print(f"Error processing proxy {proxy}: {e}")

def read_proxies(file_path):
    try:
        with open(file_path, 'r') as f:
            proxies = f.read().splitlines()
        return proxies
    except FileNotFoundError:
        print("Proxy file not found.")
        return []

def save_proxies():
    with open(input_file, 'w') as f:
        pass  # Clear the input file

def main():
    global alive_proxies, dead_proxies
    try:
        proxies = read_proxies(input_file)
        chunk_size = 100
        remaining_proxies = proxies[:]
        while remaining_proxies:
            chunk = remaining_proxies[:chunk_size]
            process_proxies(chunk)
            remaining_proxies = remaining_proxies[chunk_size:]
            save_proxies()
            with open(input_file, 'w') as f:
                f.write('\n'.join(remaining_proxies))
            print(f"Remaining proxies: {len(remaining_proxies)}")
    except KeyboardInterrupt:
        print("Interrupted. Saving progress...")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        save_proxies()

if __name__ == '__main__':
    main()